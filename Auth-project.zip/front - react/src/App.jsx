import { BrowserRouter, Routes, Route } from "react-router-dom";
import Register from "./pages/Register";
import Login from "./pages/Login";


// usamos BrowserRouter y Routes para separar por rutas el login y el register
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element = {<Login />} />
        <Route path='/register-form' element = {<Register />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
