import { useState } from "react";
import { Link } from "react-router-dom";

function Register() {


  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");


  const handleSubmit = (e) => {
    e.preventDefault();

    if (!name || !email || !password) {
      setError("Todos los campos son obligatorios");
      setTimeout(() => setError(""), 5000); 
      return;
    }
    
    if (!email.includes('@')) {
      setError("El email no es valido");
      setTimeout(() => setError(""), 5000);
      return;
    }

    setError("");

    console.log("Datos ingresados correctamente", { name, email, password });


    // Creamos la conexión al backend
    const backendUrl = "http://localhost:5000/api/auth/register";

    fetch(backendUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, password }),
    })
    .then(async (res) => {  
      const data = await res.json();

      if (!res.ok) {    
        throw new Error(data.message || "Error al registrar");
      }
      
      console.log("Usuario registrado", data);
      alert("Registro exitoso");
    })
    .catch((err) => {
      setError(err.message);
      setTimeout(() => setError(""), 5000);
    });
  };

  return (
    <div className = "form-container">
      <h2> Registrarse </h2>
      <form onSubmit={handleSubmit}>

        <input
          type="text"
          placeholder="Nombre"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <br />

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />

        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <br />

        <button type="submit">Registrarse</button>
      </form>

      <p className = "form-footer"> 
        ¿Ya tienes una cuenta? <Link to = "/"> Iniciar sesión </Link> 
      </p>

      {error && <p className="error-message">{ error }</p>}
    </div>
  );
}

export default Register;
