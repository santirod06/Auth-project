import { useState } from "react";
import { Link } from 'react-router-dom';

function Login() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");


  const handleSubmit = (e) => {
    e.preventDefault();

    if (!email || !password) {
      setError("Todos los campos son obligatorios");
      setTimeout(() => setError(""), 5000);
      return;
    }

    setError("");




    // Creamos la conexión al backend
    const backendUrl = "http://localhost:5000/api/auth/login";

    fetch(backendUrl, {
      method: "POST",
      headers: {
        "Content-type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })

    .then(async (res) => {   
      const data = await res.json();  

      if (!res.ok) {
        throw new Error(data.message || "Error al iniciar sesión"); 
      }

      alert("Sesion iniciada");
      console.log("Token guardado correctamente", data.token);
      localStorage.setItem("token", data.token);
    })
    .catch((err) => {
      console.error(err);
      setError(err.message);
      setTimeout(() => setError(""), 5000);
    });
  };




  return (
    <div className = "form-container">
      <h2> Iniciar sesión </h2>
      <form onSubmit={handleSubmit}>

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />

        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <br />

        <button type="submit"> Ingresar </button>
      </form>
      
      <p className = "form-footer"> 
        ¿No tienes una cuenta? <Link to = '/register-form'> Registrarse </Link> 
      </p>

      {error && <p className="error-message">{ error }</p>}
    </div>
  );
}

export default Login;
