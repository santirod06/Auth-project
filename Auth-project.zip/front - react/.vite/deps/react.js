import {
  require_react
} from "./chunk-Y455YYDO.js";
export default require_react();
