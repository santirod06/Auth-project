// Aqui vamos a hacer la función que verifique que el token es valido para acceder a las rutas protegidas

const jwt = require('jsonwebtoken');


//   Guardamos el token que nos llega ( viene del front con un header con nombre Authorization (key) y su token (value))
//   si viene sin problemas, lo verificamos con la firma que tuvo que haber sido creada, lo que comparará: 
//   que se haya creado con la misma firma y que no esté expirado.
//   se crea la propiedad userVerified en lo que viene del req, y se guarda la verificación, con next() le
//   decimos a express que ya termiamos de evaluar esta función y puede seguir con otra
const authMiddleware = (req, res, next) => {
    const token = req.header('Authorization'); 

    if (!token) 
        return res.status(400).json({ message: 'Acceso no permitido, no tiene token' });

    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET); 
        req.userVerified = verified;
        next(); 
    } catch (err) {
        res.status(400).json({ message: 'Token no valido' });
    }
};

module.exports = authMiddleware;