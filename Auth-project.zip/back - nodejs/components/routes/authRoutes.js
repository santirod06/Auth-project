// Módulo de rutas de autenticación para el registro de usuarios.

const express = require("express");
const router = express.Router();

const bcrypt = require("bcryptjs");           // Para hashear contraseñas
const User = require("../models/Usuario");   // Importamos el modelo de Usuario
const jwt = require('jsonwebtoken');        // Para crear los token



// 1. Creamos un endpoint para registrar un usuario con nombre, email y contraseña
//    guardamos los datos name, email y password del body (frontend) para luego en try
//    verificar si ese mail ya esta registrado, ya que no se puede repetir
//    si no lo esta creamos una contraseña hasheada con bcrypt usando 10 vueltas (cuantas más, más segura)
//    guardamos los datos en la base datos con la contraseña nueva creada con el hash.
router.post("/register", async (req, res) => {
  const { name, email, password } = req.body;   

  try {
    if (await User.findOne({ email }))          
      return res.status(400).json({ message: "Este email ya esta registrado" });

    const hashedPassword = await bcrypt.hash(password, 10);            
    await new User({ name, email, password: hashedPassword }).save();  

    res.status(201).json({ message: "Registro exitoso" });
  } catch (err) {
    res.status(500).json({ message: "Ha ocurrido un error" });
  }
});



// 2. Creamos un endpoint para hacer login.
//    buscamos el usuario con ese email en la base de datos User y lo guardamos en la constante user
//    si no lo encuentra en la base de datos le dice que no esta registrado (no hay ninguno con ese email)
//    si lo encontro, comparamos la contraseña que puso en el front con la que tiene ese user en la base de datos,
//    (compare los compara a pesar de que uno esta en hash, lo pasa al mismo tipo)
//
//    por ultimo si todo anda, crea un token con JWT, con vencimiento para que no necesite logearse para estar en la pagina
//    mientras este vigente, lo crea con el id del usuario y una firma secreta para que no se pueda falsificar el token
//    por ultimo devuelve el token para luego usarlo en el localStorage del frontend.
router.post('/login', async (req,res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email }); 
    if (!user) 
      return res.status(400).json({ message: "No hay ningun usuario registrado con ese correo" }); 
    
    const matchingPassword = await bcrypt.compare(password, user.password); 
    if (!matchingPassword)
      return res.status(400).json({ message: "La contraseña no coincide" });
  
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" }); 

    res.status(200).json({ message: "Login exitoso", token });
  } catch (err) {
    res.status(500).json({ message: "Error en el servidor" });
  }
}); 

module.exports = router;
