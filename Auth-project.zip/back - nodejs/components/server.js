const mongoose = require("mongoose");
const express = require("express");
const app = express();
const authRoutes = require("./routes/authRoutes"); 
const authMiddleware = require("./middlewares/authMiddleware"); 
require('dotenv').config();    
const cors = require("cors");   


app.use(express.json());
app.use(cors());

mongoose
  .connect("mongodb://localhost:27017/nombre-random")
  .then(() => console.log("Conectado a MongoDB")) 
  .catch((error) => console.error("Error al conectar a MongoDB", error));


app.use("/api/auth", authRoutes);


app.get("/protected", authMiddleware, (req, res) => {
  res.json({
    message: "Entraste al endpoint protegido",
    data: req.userVerified,
  });
});


app.get("/", (req, res) => {
  res.send("Servidor corriendo");
});


const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`); 
});



/*
 
  DEPENDENCIAS

    npm install dotenv
    mongoose, express, jwt, no me acuerdo q mas, schemas... 
    npm install cors

*/